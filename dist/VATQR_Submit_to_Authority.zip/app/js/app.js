let app_id, account_id;
let cachedFile = null;
let cachedBase64 = null;

ZOHO.embeddedApp.on("PageLoad", async (entity) => {
  try {
    const entity_id = entity.EntityId;
    const appResponse = await ZOHO.CRM.API.getRecord({
      Entity: "Applications1",
      approved: "both",
      RecordID: entity_id,
    });
    const applicationData = appResponse.data[0];
    app_id = applicationData.id;
    account_id = applicationData.Account_Name.id;

    const accountResponse = await ZOHO.CRM.API.getRecord({
      Entity: "Accounts",
      approved: "both",
      RecordID: account_id,
    });

    const accountData = accountResponse.data[0];

    legalNameTaxablePerson = accountData.Legal_Name_of_Taxable_Person;
    ctTrn = accountData.Corporate_Tax_TRN;
    taxPeriodVat = accountData.Tax_Period_VAT;

    var now = new Date();
    var currentYear = now.getFullYear();

    document.getElementById("name-of-taxable-person").value = legalNameTaxablePerson || "";
    document.getElementById("tax-registration-number").value = ctTrn || "";
    document.getElementById("tax-period-vat").value = taxPeriodVat || "";
    document.getElementById("financial-year").value = currentYear || "";

    // Calculate on initial load
    updateTaxPeriodEnding();

    ZOHO.CRM.UI.Resize({ height: "90%" }).then(function (data) {
      console.log("Resize result:", data);
    });
  } catch (err) {
    console.error(err);
  }
});

function clearErrors() {
  document.querySelectorAll(".error-message").forEach((span) => {
    span.textContent = "";
  });
}

function showError(fieldId, message) {
  const errorSpan = document.getElementById(`error-${fieldId}`);
  if (errorSpan) errorSpan.textContent = message;
}

function showUploadBuffer() {
  const buffer = document.getElementById("upload-buffer");
  const bar = document.getElementById("upload-progress");
  if (buffer) buffer.classList.remove("hidden");
  if (bar) {
    bar.classList.remove("animate");
    void bar.offsetWidth;
    bar.classList.add("animate");
  }
}

function hideUploadBuffer() {
  const buffer = document.getElementById("upload-buffer");
  if (buffer) buffer.classList.add("hidden");
}

function validateFinancialYear(fy) {
  if (!/^\d{4}$/.test(fy)) {
    return "Enter a four-digit year (e.g., 2025).";
  }
  const year = parseInt(fy, 10);
  if (year < 2025 || year > 2050) {
    return "Year must be between 2025 and 2050.";
  }
  return "";
}

// --- NEW: Function to calculate Tax Period Ending ---
function updateTaxPeriodEnding() {
  const fy = parseInt(document.getElementById("financial-year").value, 10);
  const taxPeriodValue = document.getElementById("tax-period-vat").value;

  if (!fy || !taxPeriodValue) {
    document.getElementById("tax-period-ending").value = "";
    return;
  }

  // Match Q1's start and end dates (e.g., "Q1: 1 Jan - 31 Mar")
  const q1Match = taxPeriodValue.match(/Q1:\s*(\d{1,2}\s\w+)\s*-\s*(\d{1,2}\s\w+)/i);
  if (q1Match) {
    const startFormatted = formatDateString(q1Match[1], fy);
    const endFormatted = formatDateString(q1Match[2], fy);
    document.getElementById("tax-period-ending").value = `${startFormatted} - ${endFormatted}`;
  } else {
    document.getElementById("tax-period-ending").value = "";
  }
}

// Helper: formats "1 Jan" into "Jan 1, 2025"
function formatDateString(dayMonthStr, year) {
  const [day, monthAbbrev] = dayMonthStr.split(" ");
  const dateObj = new Date(`${monthAbbrev} ${day}, ${year}`);
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${monthNames[dateObj.getMonth()]} ${dateObj.getDate()}, ${dateObj.getFullYear()}`;
}

// Validation + live calculation on Financial Year change
const fyInput = document.getElementById("financial-year");
if (fyInput) {
  fyInput.addEventListener("input", () => {
    fyInput.value = fyInput.value.replace(/\D/g, "").slice(0, 4);
    const err = validateFinancialYear(fyInput.value);
    if (!err) {
      const span = document.getElementById("error-financial-year");
      if (span) span.textContent = "";
    }
  });
  fyInput.addEventListener("blur", () => {
    const val = fyInput.value;
    if (/^\d{4}$/.test(val)) {
      let year = parseInt(val, 10);
      if (year < 2025) year = 2025;
      if (year > 2050) year = 2050;
      fyInput.value = String(year);
    }
    updateTaxPeriodEnding();
  });
}

// Recalculate when Tax Period VAT changes
const taxPeriodVatSelect = document.getElementById("tax-period-vat");
if (taxPeriodVatSelect) {
  taxPeriodVatSelect.addEventListener("change", updateTaxPeriodEnding);
}

async function cacheFileOnChange(event) {
  clearErrors();

  const fileInput = event.target;
  const file = fileInput?.files[0];
  if (!file) return;

  if (file.size > 20 * 1024 * 1024) {
    showError("vat-tax-return", "File size must not exceed 20MB.");
    return;
  }

  showUploadBuffer();

  try {
    const base64 = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsArrayBuffer(file);
    });

    cachedFile = file;
    cachedBase64 = base64;

    await new Promise((res) => setTimeout(res, 3000));
    hideUploadBuffer();
  } catch (err) {
    console.error("Error caching file:", err);
    hideUploadBuffer();
    showError("vat-tax-return", "Failed to read file.");
  }
}

async function uploadFileToCRM() {
  if (!cachedFile || !cachedBase64) {
    throw new Error("No cached file");
  }

  return await ZOHO.CRM.API.attachFile({
    Entity: "Applications1",
    RecordID: app_id,
    File: {
      Name: cachedFile.name,
      Content: cachedBase64,
    },
  });
}

async function update_record(event = null) {
  if (event) event.preventDefault();

  clearErrors();

  let hasError = false;
  const submitBtn = document.getElementById("submit_button_id");
  if (submitBtn) {
    submitBtn.disabled = true;
    submitBtn.textContent = "Submitting...";
  }

  const referenceNo = document.getElementById("reference-number")?.value;
  const taxablePerson = document.getElementById("name-of-taxable-person")?.value;
  const taxRegNo = document.getElementById("tax-registration-number")?.value;
  const taxPeriodVat = document.getElementById("tax-period-vat")?.value;
  const financialYear = document.getElementById("financial-year")?.value;
  const taxPeriodEnding = document.getElementById("tax-period-ending")?.value;
  const appDate = document.getElementById("application-date")?.value;
  const taxPaid = document.getElementById("tax-paid")?.value;

  if (!referenceNo) {
    showError("reference-number", "Reference Number is required.");
    hasError = true;
  }
  if (!taxablePerson) {
    showError("name-of-taxable-person", "Legal Name of Taxable Person is required.");
    hasError = true;
  }
  if (!taxRegNo) {
    showError("tax-registration-number", "Tax Registration Number is required.");
    hasError = true;
  }
  if (!taxPeriodVat) {
    showError("tax-period-vat", "Tax Period VAT is required.");
    hasError = true;
  }
  if (!financialYear) {
    showError("financial-year", "Financial Year is required.");
    hasError = true;
  }
  if (!taxPeriodEnding) {
    showError("tax-period-ending", "Tax Period Ending is required.");
    hasError = true;
  }
  if (!appDate) {
    showError("application-date", "Application Date is required.");
    hasError = true;
  }
  if (!taxPaid) {
    showError("tax-paid", "Tax Paid is required.");
    hasError = true;
  }
  if (!cachedFile || !cachedBase64) {
    showError("vat-tax-return", "Please upload the VAT Tax Return.");
    hasError = true;
  }

  if (hasError) {
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Submit";
    }
    return;
  }

  try {
    await ZOHO.CRM.API.updateRecord({
      Entity: "Applications1",
      APIData: {
        id: app_id,
        Reference_Number: referenceNo,
        Legal_Name_of_Taxable_Person: taxablePerson,
        Tax_Registration_Number_TRN: taxRegNo,
        Tax_Period_VAT: taxPeriodVat,
        Financial_Year_Ending: financialYear,
        Tax_Period_Ending: taxPeriodEnding,
        Application_Date: appDate,
        Tax_Paid: taxPaid,
      },
    });

    await ZOHO.CRM.API.updateRecord({
      Entity: "Accounts",
      APIData: {
        id: account_id,
        Legal_Name_of_Taxable_Person: taxablePerson,
        TRN_Number: taxRegNo,
        Tax_Period_VAT: taxPeriodVat,
      },
    });
    
    await uploadFileToCRM();
    await ZOHO.CRM.BLUEPRINT.proceed();
    await ZOHO.CRM.UI.Popup.closeReload();
  } catch (error) {
    console.error("Error on final submit:", error);
    if (submitBtn) {
      submitBtn.disabled = false;
      submitBtn.textContent = "Submit";
    }
  }

}

document.getElementById("vat-tax-return").addEventListener("change", cacheFileOnChange);
document.getElementById("record-form").addEventListener("submit", update_record);

async function closeWidget() {
  await ZOHO.CRM.UI.Popup.closeReload().then(console.log);
}

ZOHO.embeddedApp.init();
